import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboad',
  templateUrl: './dashboad.component.html',
  styleUrls: ['./dashboad.component.scss']
})
export class DashboadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
